<?php
/**
* The Template for displaying all single products.
*
* @version     1.6.4
*/
theme_load_template('Product Overview', 'productOverview'); ?>