<?php theme_register_template('Blog', 'blogTemplate', 'templates/blog_5.php'); ?>
<?php theme_register_template('Home', 'home', 'templates/front_1.php'); ?>
<?php theme_register_template('Product Overview', 'productOverview', 'templates/product_overview_4.php'); ?>
<?php theme_register_template('Products', 'products', 'templates/products_3.php'); ?>
<?php theme_register_template('Shopping Cart', 'shoppingCartTemplate', 'templates/cart_8.php'); ?>
<?php theme_register_template('404', 'template404', 'templates/404_9.php'); ?>